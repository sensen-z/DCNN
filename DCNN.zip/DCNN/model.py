import numpy as np
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
import os
from sklearn.metrics import mean_squared_error
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import tensorflow as tf
#config = tf.ConfigProto()
#config.gpu_options.allow_growth = True  # 不全部占满显存，按需分配
#config.gpu_options.per_process_gpu_memory_fraction = 0.3
#session = tf.Session(config=config)
import numpy as np
import time
import matplotlib.pyplot as plt
from keras.callbacks import EarlyStopping
from keras import backend as K
from sklearn import metrics
from keras.optimizers import Adam, SGD
from keras.layers import Input, Conv1D, MaxPooling1D, AveragePooling1D, GlobalAveragePooling1D,GlobalMaxPool1D, Dropout, Flatten, Dense, BatchNormalization, Activation, Concatenate, Reshape, Multiply
from keras.models import Model, load_model
from tensorflow.keras.models import Model
from keras.layers import Input, Conv1D, AveragePooling1D, GlobalAveragePooling1D, Dropout, Flatten, Dense, \
     Activation, Concatenate, Reshape, Multiply, GlobalMaxPooling1D, Add, Permute, multiply, Lambda, \
    Conv2D, GlobalAveragePooling2D
from keras.regularizers import l1, l2
from keras.layers import Input
from keras.utils import to_categorical
from scipy import interp
import warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings('ignore')
import csv
def ReadMyCsv(SaveList, fileName):
    csv_reader = csv.reader(open(fileName))
    for row in csv_reader:
        SaveList.append(row)
    return
def storFile(data, fileName):
    with open(fileName, "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(data)
    return

import numpy as np
SampleFeature = []
ReadMyCsv(SampleFeature, "..\feature.csv")
SampleFeature = np.float32(SampleFeature)
x = SampleFeature #
data = []
data1 = np.ones((1933,1), dtype=int)
data2 = np.zeros((1933,1))
y=np.concatenate((data1,data2),axis=0)
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
x_train=x_train.reshape(-1,1,906,1)
x_test=x_test.reshape(-1,1,906,1)
x = x.reshape(-1,1,906,1)
def conv_factory(x, concat_axis, filters, dropout_rate=None, weight_decay=1e-4):
    x = BatchNormalization(axis=concat_axis,
                           gamma_regularizer=l2(weight_decay),
                           beta_regularizer=l2(weight_decay))(x)
    x = Activation('relu')(x)
    x = Conv1D(filters=filters,
               kernel_size=3,
               kernel_initializer="he_uniform",
               padding="same",
               use_bias=False,
               kernel_regularizer=l2(weight_decay))(x)
    if dropout_rate:
        x = Dropout(dropout_rate)(x)
    return x
def transition(x, concat_axis, filters, dropout_rate=None, weight_decay=1e-3):
    x = BatchNormalization(axis=concat_axis,
                           gamma_regularizer=l2(weight_decay),
                           beta_regularizer=l2(weight_decay))(x)

    x = Activation('relu')(x)
    x = Conv1D(filters=filters,
               kernel_size=1,
               kernel_initializer="he_uniform",
               padding="same",
               use_bias=False,
               kernel_regularizer=l2(weight_decay))(x)
    if dropout_rate:
        x = Dropout(dropout_rate)(x)
    x = AveragePooling1D(pool_size=2, strides=2,padding="same")(x)
    return x
def denseblock(x, concat_axis, layers, filters, growth_rate, dropout_rate=None, weight_decay=1e-4):
    list_feature_map = [x]
    for i in range(layers):
        x = conv_factory(x, concat_axis, growth_rate,
                         dropout_rate, weight_decay)
        list_feature_map.append(x)
        x = Concatenate(axis=concat_axis)(list_feature_map)
        filters = filters + growth_rate
    return x, filters
def squeeze_excitation_layer(x, out_dim, ratio):
    squeeze = GlobalAveragePooling1D()(x)
    excitation = Dense(units=out_dim // ratio, activation="relu",
                       use_bias=False, kernel_initializer='he_normal')(squeeze)
    excitation = Dense(units=out_dim, activation="sigmoid",
                       kernel_initializer='he_normal')(excitation)
    excitation = Reshape((1, out_dim))(excitation)
    return Multiply()([x, excitation])
def channel_attention(input_feature, ratio=16):
    channel_axis = 1 if K.image_data_format() == "channels_first" else -1
    channel = input_feature.shape[channel_axis]
    shared_layer_one = Dense(channel // ratio,
                         kernel_initializer='he_normal',
                         activation='relu',
                         use_bias=True,
                         bias_initializer='zeros')
    shared_layer_two = Dense(channel,
                         kernel_initializer='he_normal',
                         use_bias=True,
                         bias_initializer='zeros')
    avg_pool = GlobalAveragePooling1D()(input_feature)
    avg_pool = Reshape((1, 1, channel))(avg_pool)
    assert avg_pool.shape[1:] == (1, 1, channel)
    avg_pool = shared_layer_one(avg_pool)
    assert avg_pool.shape[1:] == (1, 1, channel // ratio)
    avg_pool = shared_layer_two(avg_pool)
    assert avg_pool.shape[1:] == (1, 1, channel)
    max_pool = GlobalMaxPooling1D()(input_feature)
    max_pool = Reshape((1, 1, channel))(max_pool)
    assert max_pool.shape[1:] == (1, 1, channel)
    max_pool = shared_layer_one(max_pool)
    assert max_pool.shape[1:] == (1, 1, channel // ratio)
    max_pool = shared_layer_two(max_pool)
    assert max_pool.shape[1:] == (1, 1, channel)
    cbam_feature = Add()([avg_pool, max_pool])
    cbam_feature = Activation('hard_sigmoid')(cbam_feature)
    if K.image_data_format() == "channels_first":
       cbam_feature = Permute((3, 1, 2))(cbam_feature)
    return multiply([input_feature, cbam_feature])
def spatial_attention(input_feature):
    kernel_size = 7
    if K.image_data_format() == "channels_first":
        channel = input_feature.shape[1]
        cbam_feature = Permute((2, 3, 1))(input_feature)
    else:
        channel = input_feature.shape[-1]
        cbam_feature = input_feature
    avg_pool = Lambda(lambda x: K.mean(x, axis=3, keepdims=True))(cbam_feature)
    assert avg_pool.shape[-1] == 1
    max_pool = Lambda(lambda x: K.max(x, axis=3, keepdims=True))(cbam_feature)
    assert max_pool.shape[-1] == 1
    concat = Concatenate(axis=3)([avg_pool, max_pool])
    assert concat.shape[-1] == 2
    cbam_feature = Conv2D(filters=1,
                          kernel_size=kernel_size,
                          activation='hard_sigmoid',
                          strides=1,
                          padding='same',
                          kernel_initializer='he_normal',
                          use_bias=False)(concat)
    assert cbam_feature.shape[-1] == 1
    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((3, 1, 2))(cbam_feature)
    return multiply([input_feature, cbam_feature])
def cbam_block(cbam_feature, ratio=16):
    cbam_feature = channel_attention(cbam_feature, ratio)
    cbam_feature = spatial_attention(cbam_feature)
    return cbam_feature
def DenseNet(   nb_dense_block, growth_rate, nb_layers,
             filters, dropout_rate=None, weight_decay=1E-4):
    concat_axis = -1
    model_input = Input(shape=(1, 906))
    x= Conv1D(filters=filters, kernel_size=3,
                 kernel_initializer="he_normal",
                 padding="same",
                 use_bias=False,
                 kernel_regularizer=l2(weight_decay))(model_input)
    for block_idx in range(nb_dense_block ):
        x, filters = denseblock(x, concat_axis, nb_layers,
                                  filters, growth_rate,
                                  dropout_rate=dropout_rate,
                                  weight_decay=weight_decay)
        x = transition(x, concat_axis, filters, dropout_rate=dropout_rate,
                       weight_decay=weight_decay)
    x, filters = denseblock(x, concat_axis, nb_layers,
                              filters, growth_rate,
                              dropout_rate=dropout_rate,
                              weight_decay=weight_decay)
    x = BatchNormalization(axis=concat_axis,
                           gamma_regularizer=l2(weight_decay),
                           beta_regularizer=l2(weight_decay))(x)
    x = Activation('relu')(x)
    x = cbam_block(x)
    x = Reshape((1, 1, 176))(x)
    x = GlobalAveragePooling2D(data_format='channels_last',name='Dense-1')(x)
    x = Dense(1,
              activation='sigmoid',
              kernel_regularizer=l2(weight_decay),
              bias_regularizer=l2(weight_decay))(x)
    densenet = Model(inputs=[model_input], outputs=[x], name="DenseNet")
    densenet.compile(loss='binary_crossentropy', optimizer='adam')
    return densenet
model = DenseNet( nb_dense_block=2,growth_rate=12,nb_layers =4,filters=32,dropout_rate=0.5,weight_decay=1E-3)
model.fit(x_train, y_train, batch_size=10,epochs=500)
from keras.models import Model
dense1_layer_model = Model(inputs=model.input, outputs=model.get_layer('Dense-1').output)
dense1_output_x = dense1_layer_model.predict(x)
storFile(dense1_output_x, '..\high feature.csv')
