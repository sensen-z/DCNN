DCNN

Dataset
1. FdrugSimilarity and FdiseaseSimilarity store disease semantic similarity matrix and drug structural similarity matrix of Fdataset.
2. F-drug-disease-whole store known drug-disease associations of Fdataset.


code
1. datapro.py:The process of data processing.
2. model.py:The process of feature.
3. RF.py:predict potential indications for drugs.
