#from RotationForest import RotationForest
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier,bagging
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from numpy import *
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
import numpy as np
import random
import csv
from keras.datasets import mnist
from numpy import *
import numpy as np
np.random.seed(1337)
data = []
data1 = ones((1, 1933), dtype=int)
data2 = zeros((1, 1933))
data.extend(data1[0])
data.extend(data2[0])
SampleLabel = data
A=data
def ReadMyCsv(SaveList, fileName):
    csv_reader = csv.reader(open(fileName))
    for row in csv_reader:
        SaveList.append(row)
    return
SampleFeature = []
ReadMyCsv(SampleFeature, '..\high feature.csv')
x_train, x_test, y_train, y_test = train_test_split(SampleFeature, SampleLabel, test_size=0.1)
print('Start training the model.')
cv = StratifiedKFold(n_splits=10)
SampleFeature = np.array(SampleFeature)
SampleLabel = np.array(SampleLabel)
permutation = np.random.permutation(SampleLabel.shape[0])
SampleFeature = SampleFeature[permutation, :]
SampleLabel = SampleLabel[permutation]

tprs = []
aurocs=[]
mean_fpr = np.linspace(0, 1, 100)#np.linspace主要用来创建等差数列
mean_rec = np.linspace(0, 1, 100)
pres = []
auprs = []
i = 0
num=0
for train, test in cv.split(SampleFeature, SampleLabel):
    model = RandomForestClassifier(n_estimators=100,max_depth=200)
    predicted = model.fit(SampleFeature[train], SampleLabel[train]).predict_proba(SampleFeature[test])
    fpr, tpr, thresholds = roc_curve(SampleLabel[test], predicted[:, 1])
    from sklearn.metrics import precision_recall_curve
    precision, recall, pr_thresholds = precision_recall_curve(y_true=SampleLabel[test], probas_pred=predicted[:, 1],pos_label=1)
    predicted1 = model.predict(SampleFeature[test])
    num = num + 1
    print("==================", num, "fold", "==================")
    print('Test accuracy: ', accuracy_score(SampleLabel[test], predicted1))
    print(classification_report(SampleLabel[test], predicted1, digits=4))
    print(confusion_matrix(SampleLabel[test], predicted1))
    from scipy.interpolate import interp1d
    plt.subplot(1, 2, 1)
    fpr, tpr, auc_thresholds = roc_curve(SampleLabel[test], predicted[:, 1], pos_label=1)
    auroc_score = auc(fpr, tpr)
    aurocs.append(auroc_score)
    f1 = interp1d(fpr, tpr, kind='linear')
    interp1d_tpr = f1(mean_fpr)
    interp1d_tpr[0] = 0.0
    interp1d_tpr[-1] = 1.0
    tprs.append(interp1d_tpr)
    plt.plot(fpr, tpr, lw=1, alpha=0.4, label='ROC fold %d(area=%0.4f)' % (i, auroc_score))
    aupr_score = auc(recall, precision)
    auprs.append(aupr_score)
    f2 = interp1d(recall, precision, kind='linear')
    interp1d_pre = f2(mean_rec)
    interp1d_pre[0] = 1.0
    interp1d_pre[-1] = 0.0
    pres.append(interp1d_pre)
    i += 1
plt.subplot(1, 2, 1)
plt.plot([0, 1], [0, 1], linestyle='--', lw=1, color='r', alpha=.8)
mean_tpr = np.mean(tprs, axis=0)
mean_auroc = np.mean(aurocs)
std_auroc = np.std(aurocs)
plt.plot(mean_fpr, mean_tpr, color='b',label=r'Mean ROC (AUC = %0.4f $\pm$ %0.4f)' % (mean_auroc, std_auroc), lw=2, alpha=.8)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xticks(fontproperties='Times New Roman', size=6)
plt.yticks(fontproperties='Times New Roman', size=6)
plt.xlabel('FPR', fontdict={'family': 'Times New Roman', 'size': 8})
plt.ylabel('TPR', fontdict={'family': 'Times New Roman', 'size': 8})
plt.title('(a) ROC', fontdict={'family': 'Times New Roman', 'size': 10})
plt.legend(loc="lower right", prop={'family': 'Times New Roman', 'size': 6})
plt.show()
plt.close()




